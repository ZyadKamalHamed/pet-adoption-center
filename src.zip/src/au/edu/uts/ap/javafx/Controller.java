package au.edu.uts.ap.javafx;

import controller.ErrorController;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.*;
import java.io.IOException;

public abstract class Controller<M> {
    protected M model;
    protected Stage stage;
    @FXML private Button closeBtn;

}