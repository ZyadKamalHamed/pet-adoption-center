package model.Animals;

public class Rabbit extends Animal {
    public Rabbit(String name, int age) {
        super(name, age);
    }
}